SportRadar Liechtenstein – Website-Datei

So öffnest du die Website:
1. Entpacke sportradar_liechtenstein.zip.
2. Öffne index.html in einem Browser (z. B. Chrome).

Wichtig:
- Dies ist eine erste Website-Vorlage, die du lokal öffnen kannst.
- Die Filter und Navigation funktionieren.
- Es sind keine offiziellen Live-Ergebnisse eingebaut; es werden keine Resultate erfunden.
- Um die Website für andere öffentlich erreichbar zu machen, musst du sie noch auf einen Hosting-Dienst hochladen (z. B. GitHub Pages).
